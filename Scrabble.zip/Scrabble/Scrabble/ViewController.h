//
//  ViewController.h
//  Scrabble
//
//  Created by Ryan Badham on 28/10/2014.
//  Copyright (c) 2014 RYAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>


@end
